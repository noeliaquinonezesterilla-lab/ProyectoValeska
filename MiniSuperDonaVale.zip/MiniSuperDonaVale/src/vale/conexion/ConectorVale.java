/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vale.conexion;
import java.sql.Connection;
import java.sql.DriverManager;

public class ConectorVale {
    private Connection cadena;

    public Connection obtenerConexion() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            // Conectamos directo a la nueva base de datos super_vale
            cadena = DriverManager.getConnection("jdbc:mysql://localhost:3306/super_vale", "root", "123456789");
        } catch (Exception e) {
            System.err.println("Error en ConectorVale: " + e.getMessage());
        }
        return cadena;
    }
}