/*CREATE DATABASE super_vale;
USE super_vale;

CREATE TABLE productos_vale (
    id_art INT PRIMARY KEY,
    descripcion_art VARCHAR(100),
    precio_art DECIMAL(10,2),
    existencia_art INT
);

-- Metamos unos productos nuevos de golpe para que la tabla tenga vida
INSERT INTO productos_vale VALUES 
(501, 'Aceite Girasol 1Lt', 2.25, 15),
(502, 'Arroz Súper Extra 1kg', 0.80, 50),
(503, 'Atún Van Camps Trozos', 1.75, 4), -- Stock bajo
(504, 'Café Buendía 100g', 3.40, 12),
(505, 'Leche Vita Funda', 0.95, 3); -- Stock bajo*/
INSERT INTO productos_vale (id_art, descripcion_art, precio_art, existencia_art) VALUES
(506, 'Gatorade Blue 500ml', 1.25, 18),
(507, 'Coca Cola Retornable 2Lt', 1.50, 22),
(508, 'Fanta Naranja 300ml', 0.55, 35),
(509, 'Papas Duck Pringles', 2.80, 3),  -- Stock crítico
(510, 'Doritos Mega Queso', 1.60, 14),
(511, 'Chocolate Manicho', 0.40, 40),
(512, 'Mayonesa Fruco Doypack', 1.10, 2),  -- Stock crítico
(513, 'Salsa de Tomate Maggi', 1.30, 16),
(514, 'Fideos Don Vittorio 400g', 0.70, 28),
(515, 'Sopa Americana Maggi', 0.60, 30),
(516, 'Atún Real en Aceite', 1.65, 5),
(517, 'Café Nescafe Tarro 100g', 4.20, 2),  -- Stock crítico
(518, 'Mermelada Facundo Fresa', 1.85, 8),
(519, 'Pan Supán Familiar', 2.10, 11),
(520, 'Mantequilla Girasol 250g', 1.15, 4),  -- Stock crítico
(521, 'Yogurt Toni Litro Frutilla', 2.40, 9),
(522, 'Queso Crema Kiri', 1.90, 6),
(523, 'Lavavajillas Axion Pasta', 1.45, 15),
(524, 'Shampoo Sedal Ceramidas', 3.50, 3),  -- Stock crítico
(525, 'Ace de Limón 1kg', 2.75, 7);