/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

public class Carrera {
    private int id;
    private String nombre;

    public Carrera(int id, String nombre) {
        this.id = id;
        this.nombre = nombre;
    }

    public Carrera(String nombre) {
        this.nombre = nombre;
    }

    // Getters y setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    @Override
   public String toString() {
    return nombre; // Esto mostrará solo el nombre de la carrera
    }
}

