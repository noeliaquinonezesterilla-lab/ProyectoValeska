/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;


import DAO.AlumnoDAO;
import DAO.CarreraDAO;
import Modelo.Alumno;
import Modelo.Carrera;

import java.util.List;

public class AlumnoController {
    private AlumnoDAO alumnoDAO = new AlumnoDAO();
    private CarreraDAO carreraDAO = new CarreraDAO();

    // Registrar un nuevo alumno
    public boolean registrarAlumno(String nombre, int edad, Carrera carrera) {
    if (nombre == null || nombre.trim().isEmpty() || carrera == null) {
        return false;
    }
    
    Alumno alumno = new Alumno(nombre, edad, carrera);
    return alumnoDAO.agregarAlumno(alumno);
}

    // Listar todos los alumnos
    public List<Alumno> obtenerAlumnos() {
        return alumnoDAO.listarAlumnos();
    }

    // Eliminar alumno por ID
    public boolean eliminarAlumno(int idAlumno) {
        return alumnoDAO.eliminarAlumno(idAlumno);
    }

    // Obtener todas las carreras (para JComboBox)
    public List<Carrera> obtenerCarreras() {
        return carreraDAO.obtenerCarreras();
    }

    // Registrar nueva carrera desde otra ventana
    public boolean registrarCarrera(String nombreCarrera) {
        Carrera nueva = new Carrera(nombreCarrera);
        return carreraDAO.agregarCarrera(nueva);
    }
}

