/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import Conexion.ConexionDB;
import Modelo.Alumno;
import Modelo.Carrera;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AlumnoDAO {

    public boolean agregarAlumno(Alumno alumno) {
    String sql = "INSERT INTO alumno (nombre, edad, id_carrera) VALUES (?, ?, ?)";
    
    try (Connection conn = ConexionDB.getConnection();
         PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
        
        ps.setString(1, alumno.getNombre());
        ps.setInt(2, alumno.getEdad());
        ps.setInt(3, alumno.getCarrera().getId());
        
        int filasAfectadas = ps.executeUpdate();
        
        if (filasAfectadas > 0) {
            try (ResultSet generatedKeys = ps.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    alumno.setId(generatedKeys.getInt(1));
                }
            }
            return true;
        }
    } catch (SQLException e) {
        System.err.println("Error al insertar alumno: " + e.getMessage());
        e.printStackTrace();
    }
    return false;
}

    public List<Alumno> listarAlumnos() {
        List<Alumno> lista = new ArrayList<>();
        String sql = "SELECT a.id, a.nombre, a.edad, c.id AS id_carrera, c.nombre AS nombre_carrera " +
                 "FROM alumno a " +
                 "JOIN carrera c ON a.id_carrera = c.id";

        try (Connection conn = ConexionDB.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Carrera carrera = new Carrera(rs.getInt("id_carrera"), rs.getString("nombre_carrera"));
                Alumno alumno = new Alumno(
                    rs.getInt("id"),
                    rs.getString("nombre"),
                    rs.getInt("edad"),
                    carrera
                );
                lista.add(alumno);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return lista;
    }

    public boolean eliminarAlumno(int idAlumno) {
        String sql = "DELETE FROM alumno WHERE id = ?";

        try (Connection conn = ConexionDB.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, idAlumno);
            ps.executeUpdate();
            return true;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
