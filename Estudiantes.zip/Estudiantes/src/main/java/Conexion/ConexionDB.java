/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Conexion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConexionDB {
    // Configuración para XAMPP sin contraseña
    private static final String URL = "jdbc:mysql://localhost:8889/universidad";
    private static final String USER = "root";  // Usuario por defecto de XAMPP
    private static final String PASSWORD = "root";  // Cadena vacía para sin contraseña

    static {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

   public static Connection getConnection() throws SQLException {
    System.out.println("Intentando conectar a: " + URL);
    Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
    System.out.println("Conexión exitosa!");
    return conn;
}
}